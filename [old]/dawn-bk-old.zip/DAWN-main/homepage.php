<?php include_once('include/navbar.php') ?>


<style> 

.banner_top_img {
    width: 100%;
    height: auto;
}
.banner_col {
    margin: 0;
    padding: 0;
}
.banner_row {
    margin: 0;
    padding: 0;
}
.banner_sec_img {
    width: 100%;
    height: auto;
}

</style>


<div class="banner_home">
    <div class="banner_top">
        <img src="dist/img/banner.jpg" class="banner_top_img" alt="">
    </div>

    <div class="banner_sec1">
        <div class="row banner_row">
            <div class="col-sm banner_col">
                <img src="dist/img/banner_sec.jpg" class="banner_sec_img" alt="">
            </div>
            <div class="col-sm banner_col">
                <img src="dist/img/banner_sec.jpg" class="banner_sec_img" alt="">
            </div>
        </div>
    </div>
    <div class="banner_sec2">
        <div class="row banner_row">
            <div class="col-sm banner_col">
                <img src="dist/img/banner_sec.jpg" class="banner_sec_img" alt="">
            </div>
            <div class="col-sm banner_col">
                <img src="dist/img/banner_sec.jpg" class="banner_sec_img" alt="">
            </div>
        </div>
    </div>
</div>

<?php include_once('include/footer.php') ?>