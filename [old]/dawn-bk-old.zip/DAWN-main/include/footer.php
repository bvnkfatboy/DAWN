<style>

footer{
    width: 100%;
    height: 150px;
    /* background-color: black; */
    margin: 0;
    padding: 0;
}


.footer_row {
    margin: 0;
    padding: 0;
}


.footer_img{
    height: auto;
    width: 100%;
    max-width: 100px;
    display: block;
    margin-left: auto;
    margin-right: auto;

}

.footer_col1{
    /* margin-top: 40px; */
    text-align: center;
}

</style>

<footer>
    <div class="footer">
        <div class="row footer_row">
            <div class="col-sm-12 footer_col1">
                <img src="dist/img/logo_dawn.png" class="footer_img" alt="">
                <small>&copy; Copyright 2020, DAWN (Coffee & Bar) </small>
            </div>
        </div>
    </div>
</footer>

